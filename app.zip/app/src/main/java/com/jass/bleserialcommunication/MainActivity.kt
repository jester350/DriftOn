import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.jass.bleserialcommunication.R

class MainActivity : AppCompatActivity() {

    private lateinit var bleHelper: BLEHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bleHelper = BLEHelper(this)
        bleHelper.startScan()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            BLEHelper.REQUEST_ENABLE_BT -> {
                if ((grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })) {
                    // Permission granted, start the scan
                    bleHelper.startScan()
                } else {
                    // Permission denied, handle accordingly
                    Log.e("BLEHelper", "Permission denied")
                }
            }
        }
    }
}
